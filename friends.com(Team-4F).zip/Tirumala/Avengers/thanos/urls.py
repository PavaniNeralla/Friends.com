from django.urls import path
from . import views

urlpatterns = [
	path('', views.index, name='index'),
	path('about', views.about, name='about'),
	path('loginpage', views.loginpage, name='loginpage'),
	path('loginpage_submit', views.loginpage_submit, name='loginpage_submit'),
	path('signin', views.signin, name='signin'),
	path('homepage',views.homepage,name='homepage'),
	path('check',views.check,name='check'),

]
