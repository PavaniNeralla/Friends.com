from django.apps import AppConfig


class ThanosConfig(AppConfig):
    name = 'thanos'
