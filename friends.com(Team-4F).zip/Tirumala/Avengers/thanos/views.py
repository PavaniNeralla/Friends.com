from django.shortcuts import render
from .models import uma


# Create your views here.

def index(request):
	return render(request, 'index.html')
def about(request):
	return render(request, 'about.html')
def loginpage(request):
	return render(request, 'loginpage.html')
def loginpage_submit(request):
	print("your form is submitted")
	name = request.POST["name"]
	email = request.POST["email"]
	password = request.POST["password"]

	label = uma(name=name,email=email,password=password)
	label.save()
	return render(request, 'signin.html')
def signin(request):
	return render(request, 'signin.html')

def homepage(request):
	return render(request, 'homepage.html')
def check(request):
	return render(request, 'index.html')


